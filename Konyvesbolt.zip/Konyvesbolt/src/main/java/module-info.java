module hu.adatb {
    requires javafx.controls;
    requires java.naming;
    requires java.sql;
    requires ojdbc8;
    exports hu.adatb;
}